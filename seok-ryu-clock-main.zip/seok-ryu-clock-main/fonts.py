import pygame

fonts = pygame.font.get_fonts()
print(fonts)